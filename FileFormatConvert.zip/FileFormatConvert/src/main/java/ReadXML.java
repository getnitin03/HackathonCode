import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.util.HashMap;

public class ReadXML {
	
	public static void main(String argv[]) {
		
	    try {
	    Configuration CF = new Configuration();
		HashMap<String,String> HM = new HashMap<String,String>();
		HM = CF.ReadConfiguration();
		//Assign values
		//System.out.println(HM.get("PDF_FilePath"));
		String XFilepath = HM.get("XML_FilePath").replace("\\", "/");	
		//File fXmlFile = new File("C:/Users/HP/Downloads/SampleInputs/SampleXML.xml");
		File fXmlFile = new File(XFilepath);
		String ParentNode = HM.get("XML_ParentNode");
		String Attribute = HM.get("XML_Attribute");
		String TagList = HM.get("XML_Tag");
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);
				
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName(ParentNode);
		HashMap<String,String> parserMap = new HashMap<String,String>();
		String[] splitTagList = TagList.split(",",0);
		
		
		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				if(Attribute!=null){
					for(int i=0;i<=splitTagList.length;i++){
						if(i==splitTagList.length){
							if(temp==0){
								parserMap.put(Attribute,eElement.getAttribute(Attribute) );
							}else{
								String oldVal = parserMap.get(Attribute);
								String newVal = oldVal + "," + eElement.getAttribute(Attribute);
								parserMap.put(Attribute,newVal);
							}
						}else{
							if(temp==0){
								parserMap.put(splitTagList[i], eElement.getElementsByTagName(splitTagList[i]).item(0).getTextContent());
							}else{
								String oldVal = parserMap.get(splitTagList[i]);
								String newVal = oldVal + "," + eElement.getElementsByTagName(splitTagList[i]).item(0).getTextContent();
								parserMap.put(splitTagList[i],newVal);
							}
						}
					}
					
				}else{
					for(int i=0;i<splitTagList.length;i++){
						if(temp==0){
							parserMap.put(splitTagList[i], eElement.getElementsByTagName(splitTagList[i]).item(0).getTextContent());
						}else{
							String oldVal = parserMap.get(splitTagList[i]);
							String newVal = oldVal + "," + eElement.getElementsByTagName(splitTagList[i]).item(0).getTextContent();
							parserMap.put(splitTagList[i],newVal);
						}
						
					}
				}
					
			}
		}
		//System.out.println(parserMap);
		OutputFile OF = new OutputFile(parserMap);
		System.out.println(parserMap);
	    OF.CreateResultFile();
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	  }
}
