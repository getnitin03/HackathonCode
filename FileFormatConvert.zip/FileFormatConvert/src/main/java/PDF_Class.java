import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.text.PDFTextStripper;

public class PDF_Class {
	//Input variables
	private String FPath;
	private Integer SPage;
	private Integer LPage;
	private Integer SPPage;
	private Integer SRow;
	private Integer LRow;
	private String ReadAll;
	private Integer Sline;
	
	private static String ReadText;
	private static int TotalPDFpages;
	
	public  PDF_Class(String pFilepath, Integer sPage, Integer lPage, Integer spPage, Integer sRow, Integer lRow,String readAll,Integer Sline){
		this.FPath = pFilepath;
		this.SPage = sPage;
		this.LPage = lPage;
		this.SPPage = spPage;
		this.SRow = sRow; 
		this.LRow = lRow;
		this.ReadAll = readAll; 
		this.Sline = Sline;
	}
	
	
	//Method to Read PDF File
	@SuppressWarnings("unchecked")
	public void ReadPDFFile() throws IOException{
		//Loading PDF File
		File PFile = new File(FPath);
		PDDocument Mdoc = PDDocument.load(PFile);
		PDFTextStripper PSTripper = new PDFTextStripper();
		//Extract total number of pages
		TotalPDFpages = Mdoc.getNumberOfPages();
		
		//ReadAll gets first priority
		if(!ReadAll.equals(null) && !ReadAll.trim().equals("") && !ReadAll.trim().equalsIgnoreCase("NO")){
			if(ReadAll.equalsIgnoreCase("YES")){
				//Code to extract entire PDF text
				System.out.println(TotalPDFpages);
				for(int i=1;i<=TotalPDFpages;i++){
					PSTripper.setStartPage(i);
					PSTripper.setEndPage(i);
					
					//Read text
					ReadText = PSTripper.getText(Mdoc);
					//System.out.println("Page is "+i);
					//System.out.println(ReadText);
				}
			}
		}else{
			//specific page gets second priority
			//System.out.println("inside specific page condition"+SPPage);
			if(!SPPage.equals(null) && SPPage>0){
				PSTripper.setStartPage(SPPage);
				PSTripper.setEndPage(SPPage);
				
				
				//Read text
				ReadText = PSTripper.getText(Mdoc);
				//System.out.println("Page is "+SPPage);
				//String[] line = ReadText.split("\\r?\\n");
				//for(String str:line){
				//	System.out.println(str+"newline");
				//}
				//System.out.println(ReadText);
			}else{ //Start and Last page get last priority
				
				if(SPage.equals(null) || SPage<=0){
					SPage = 1; //assign by default first page
				}
				if(LPage.equals(null) || LPage<=0){
					LPage = TotalPDFpages; //assign last page
				}
				
				for(int i=SPage;i<=LPage;i++){
					PSTripper.setStartPage(i);
					PSTripper.setEndPage(i);
					
					//Read text
					ReadText = PSTripper.getText(Mdoc);
					//String[] line = ReadText.split("\\r?\\n");
					//for(String str:line){
					//	System.out.println(str+"newline");
					//}
					//System.out.println("Page is "+i);
					//System.out.println(ReadText);
					
				}
			}
		}
		String[] line = ReadText.split("\\r?\\n");
		ArrayList<String> AL = new ArrayList<String>();
		for(int k= Sline-1;k<line.length;k++){
			String[] SpLine = line[k].split(",",0); 
			AL.add(line[k]);
			System.out.println(line[k]);
			/*for(int j= 0;j<SpLine.length;j++){
			System.out.println(line);
				AL.add(SpLine[j]);	
			}
		*/
		}
		//System.out.println(AL.get(0));
		
		DataParser dbparsar = new DataParser(AL,",","All"); 
	     HashMap<String,String> PrintValue = new HashMap<String,String>(); 
	     PrintValue = dbparsar.parseData();
	     //System.out.println(x);
	     OutputFile OF = new OutputFile(PrintValue);
	     OF.CreateResultFile();
		
		//return ReadText;
	}
		
	
}
