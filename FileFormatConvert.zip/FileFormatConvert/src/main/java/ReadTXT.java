import java.io.File;
import java.io.IOException;
import java.util.HashMap;
public class ReadTXT {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {

		Configuration cf = new Configuration();
		
		HashMap<String,String> HM = new HashMap<String,String>();
		HM = cf.ReadConfiguration();
		
		//String CFilePath = "C:\\Users\\kaps\\Downloads\\CSVFile2.csv";
	
		String CFilePath = HM.get("TXT_FilePath");
		
		String CSelectedCol =  HM.get("TXT_SelectedCol").trim();
          String CDelimiter = HM.get("TXT_Delimiter");
		
		
		
		Integer CskipLine = Integer.parseInt((HM.get("TXT_SkipLine")));
		
		String Cquotechar = HM.get("TXT_QuoteChar");
		//System.out.println(Cquotechar);
		
	//ParseFullCSV ps = new ParseFullCSV(CFilePath,CSelectedCol,CDelimiter,CskipLine,Cquotechar);
		ParseFullTxt ptxt = new ParseFullTxt(CFilePath,CSelectedCol,CDelimiter,CskipLine,Cquotechar);
		//ps.methodReadCSV();
		
		ptxt.methodReadCSV();
		
		
		
		

 }
}