import java.io.BufferedReader;
import java.io.FileNotFoundException; 
import java.io.FileReader;
import java.io.IOException; 
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
 
public class ParseFullCSV {
   @SuppressWarnings("resource")
 
   
   private String CsvDelmiter ;
   private String CsvSelectedCol; 
   private String CsvFilePath;
   private Integer CsvSkipLine;
   private String quoteChar;
    
   
  
   public ParseFullCSV(String CsvFilePath,String CsvSelectedCol,String CsvDelmiter,Integer CsvSkipLine,String quoteChar) {
	// TODO Auto-generated constructor stub
	   
	      this.CsvDelmiter = CsvDelmiter;
	      this.CsvSelectedCol = CsvSelectedCol;
	      this.CsvFilePath = CsvFilePath;
	      this.CsvSkipLine = CsvSkipLine;
	      this.quoteChar = quoteChar;
}


	//public static void main(String[] args) throws IOException {

	  
 @SuppressWarnings("unchecked")
public void methodReadCSV() throws IOException { 
	  // ArrayList<String> arList=null;
	 
	   char csvDelim = (this.CsvDelmiter).replace("\"","").charAt(0);
	   char csvQuote = (this.quoteChar).charAt(0);
	 // System.out.println(csvDelim);
      
	 //  BufferedReader br = new BufferedReader(new FileReader(this.CsvFilePath));
       CSVParser parser = new CSVParserBuilder().withSeparator(csvDelim).build(); 
       
 
       // create csvReader object with parameter 
       // filereader and parser 
       System.out.println(this.CsvFilePath);
       CSVReader csvReader = new CSVReaderBuilder(new FileReader(this.CsvFilePath)).withSkipLines(this.CsvSkipLine).withCSVParser(parser).build(); 
      
       
      
     //  System.out.println(header[0]);
      
       String HeaderSelect;
       
       if(!(this.CsvSelectedCol).equals(null)){
    	  // ArrayList<String> HeadSel = new ArrayList<String>();   
    	     HeaderSelect = this.CsvSelectedCol;
    	  /*for(int k=0;k<HeaderSelect.length;k++){
    		 HeadSel.add(HeaderSelect[k]); 
    	  }*/
    		  
    			  
    			  
       }else{
    	   HeaderSelect = null;
       }
       
    	if(!(csvReader.equals(null))){
    	
    	        
       //Read all rows at once
    	    	    		
        ArrayList<String[]> allRows = (ArrayList<String[]>) csvReader.readAll();
       //Read CSV line by line and use the string array as you want
       // System.out.println(allRows.size());
     	 ArrayList<String> AL = new ArrayList<String>();
          for(String[] row : allRows){
      	  // System.out.println(row);
      	    for(String cell:row){
      	       	AL.add(cell);
      		//System.out.println((cell + "\t"));	 
          	 }
          }  
     
     
     DataParser dbparsar = new DataParser(AL, ",",HeaderSelect); 
      
      HashMap<String,String> PrintValue = new HashMap<String,String>(); 
      PrintValue = dbparsar.parseData();
      OutputFile OF = new OutputFile(PrintValue);
      OF.CreateResultFile();
      //Iterator<Integer> IT = new PrintValue.iterator();
      
      System.out.println(PrintValue);
    	}
   }
}