import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;

public class Configuration {

	public HashMap ReadConfiguration() throws IOException {
		String ConFPath = "C:/Selenium Classes/Selenium_Session_8/FileFormatConvert/src/main/resources/Configuration.txt";
		File ConfigFile = new File(ConFPath);
		BufferedReader br = new BufferedReader(new FileReader(ConfigFile));
		String configReader;
	
		//Declare Hash Map to store the values
		HashMap<String,String> HM = new HashMap<String,String>();
		
		while((configReader=br.readLine())!=null){
		
			if(configReader.contains("PDF_")){
				
				String[] SpCR = configReader.trim().split("=",0);  
				if(SpCR[0].trim().equalsIgnoreCase("PDF_FilePath")){
					HM.put(SpCR[0].trim(), SpCR[1].trim());
				}else if(SpCR[0].trim().equalsIgnoreCase("PDF_SpecificPage")){
					HM.put(SpCR[0].trim(), SpCR[1].trim());
				}else if(SpCR[0].trim().equalsIgnoreCase("PDF_ReadAll")){
					HM.put(SpCR[0].trim(), SpCR[1].trim());
				}else if(SpCR[0].trim().equalsIgnoreCase("PDF_StartPage")){
					HM.put(SpCR[0].trim(), SpCR[1].trim());
				}else if(SpCR[0].trim().equalsIgnoreCase("PDF_LastPage")){
					HM.put(SpCR[0].trim(), SpCR[1].trim());
				}else if(SpCR[0].trim().equalsIgnoreCase("PDF_StartLine")){
					HM.put(SpCR[0].trim(), SpCR[1].trim());
				}
				}
			
				else if (configReader.trim().contains("CSV_")){
					
					String[] SpCSV= configReader.trim().split("=",0);
					if(SpCSV[0].trim().equalsIgnoreCase("CSV_FilePath")){
						HM.put(SpCSV[0].trim(), SpCSV[1].trim());
						
					}
					if(SpCSV[0].trim().equalsIgnoreCase("CSV_Delimiter")){
						HM.put(SpCSV[0].trim(), SpCSV[1].trim());
					}
					if(SpCSV[0].trim().equalsIgnoreCase("CSV_SkipLine")){
						HM.put(SpCSV[0].trim(), SpCSV[1].trim());
					}
					
					if(SpCSV[0].trim().equalsIgnoreCase("CSV_SelectedCol")){
						//System.out.println(SpCSV[0]);
						HM.put(SpCSV[0].trim(), SpCSV[1].trim());
					}
					
					if(SpCSV[0].trim().equalsIgnoreCase("CSV_QuoteChar")){
						HM.put(SpCSV[0].trim(), SpCSV[1].trim());
					}
					
				}else if (configReader.trim().contains("TXT_")){
					
					String[] SpCSV= configReader.trim().split("=",0);
					if(SpCSV[0].trim().equalsIgnoreCase("TXT_FilePath")){
						HM.put(SpCSV[0].trim(), SpCSV[1].trim());
						
					}
					if(SpCSV[0].trim().equalsIgnoreCase("TXT_Delimiter")){
						HM.put(SpCSV[0].trim(), SpCSV[1].trim());
					}
					if(SpCSV[0].trim().equalsIgnoreCase("TXT_SkipLine")){
						HM.put(SpCSV[0].trim(), SpCSV[1].trim());
					}
					
					if(SpCSV[0].trim().equalsIgnoreCase("TXT_SelectedCol")){
						//System.out.println(SpCSV[0]);
						HM.put(SpCSV[0].trim(), SpCSV[1].trim());
					}
					
					if(SpCSV[0].trim().equalsIgnoreCase("TXT_QuoteChar")){
						HM.put(SpCSV[0].trim(), SpCSV[1].trim());
					}
					
				}
				else if(configReader.trim().contains("XML_")){
					String[] SpCR = configReader.trim().split("=",0);  
					if(SpCR[0].trim().equalsIgnoreCase("XML_FilePath")){
						HM.put(SpCR[0].trim(), SpCR[1].trim());
					}else if(SpCR[0].trim().equalsIgnoreCase("XML_ParentNode")){
						HM.put(SpCR[0].trim(), SpCR[1].trim());
					}else if(SpCR[0].trim().equalsIgnoreCase("XML_Attribute")){
						HM.put(SpCR[0].trim(), SpCR[1].trim());
					}else if(SpCR[0].trim().equalsIgnoreCase("XML_Tag")){
						HM.put(SpCR[0].trim(), SpCR[1].trim());
					}			
				}
			}
		
				
		return HM;
	}
	
	
}
