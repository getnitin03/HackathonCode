import java.io.BufferedReader;
import java.io.FileNotFoundException; 
import java.io.FileReader;
import java.io.IOException; 
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/*import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;*/

import java.io.FileReader;
import java.util.Arrays;
import java.util.List;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
public class CsvSelectedCol {

	public static void main(String[] args) throws FileNotFoundException {
           char delimiter = ',';
	    // 1st, config the CSV reader
	    CsvParserSettings settings = new CsvParserSettings();
	    settings.getFormat().setDelimiter(delimiter);
	    settings.getFormat().setLineSeparator("\n");
	    settings.selectFields("Fname","Lname");

	    // 2nd, creates a CSV parser with the configs
	    CsvParser parser = new CsvParser(settings);

	    // 3rd, parses all rows of data in selected columns from the CSV file into a matrix
	    List<String[]> resolvedData = parser.parseAll(new FileReader("C:\\Users\\kaps\\Downloads\\CSVFile2.csv"));

	    // 3rd, process the matrix with business logic
	    for (String[] row : resolvedData) {
	        StringBuilder strBuilder = new StringBuilder();
	        for (String col : row) {
	            strBuilder.append(col).append("\t");
	        }
	        System.out.println(strBuilder);
	    }
	}}