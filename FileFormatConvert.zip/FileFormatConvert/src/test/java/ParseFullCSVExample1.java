import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException; 
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
 
public class ParseFullCSVExample1{
   @SuppressWarnings("resource")
   public static void main(String[] args) throws Exception
   {
	   ArrayList<String> arList=null;
      //Build reader instance
	   
	   // create csvParser object with 
       // custom seperator semi-colon 
       CSVParser parser = new CSVParserBuilder().withSeparator(',').build(); 
 
       // create csvReader object with parameter 
       // filereader and parser 
       CSVReader csvReader = new CSVReaderBuilder(new FileReader("C:\\Users\\kaps\\Downloads\\CSVFile2.csv")).withSkipLines(0) .withCSVParser(parser) 
                                 .build(); 
      //Read all rows at once
       String [] nextLine; /* for every line in the file */            
       int lnNum = 0; /* line number */
       /* Step -2 : Define POI Spreadsheet objects */          
       HSSFWorkbook new_workbook = new HSSFWorkbook(); //create a blank workbook object
       HSSFSheet sheet = new_workbook.createSheet("CSV2XLS");  //create a worksheet with caption score_details
       /* Step -3: Define logical Map to consume CSV file data into excel */
       
       
       Map<String, Object[]> excel_data = new HashMap<String, Object[]>(); //create a map and define data
       /* Step -4: Populate data into logical Map */
       while ((nextLine = csvReader.readNext()) != null) {
               lnNum++;                        
               excel_data.put(Integer.toString(lnNum), new Object[] {nextLine[0]});                        
       }
       /* Step -5: Create Excel Data from the map using POI */
       Set<String> keyset = excel_data.keySet();
       int rownum = 0;
       for (String key : keyset) { //loop through the data and add them to the cell
               Row row = sheet.createRow(rownum++);
               Object [] objArr = excel_data.get(key);
               int cellnum = 0;
               for (Object obj : objArr) {
                       Cell cell = row.createCell(cellnum++);
                       if(obj instanceof Double)
                               cell.setCellValue((Double)obj);
                       else
                               cell.setCellValue((String)obj);
                       }
       }
       /* Write XLS converted CSV file to the output file */
       FileOutputStream output_file = new FileOutputStream(new File("C:\\Users\\kaps\\Downloads\\test.xls")); //create XLS file
       new_workbook.write(output_file);//write converted XLS file to output stream
       output_file.close(); //close the file
}}