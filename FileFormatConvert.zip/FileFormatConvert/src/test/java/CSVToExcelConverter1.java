import java.io.BufferedReader;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;


public class CSVToExcelConverter1 {

	 public static void main(String args[]) throws IOException
     {
         ArrayList<String> arList=null;
         ArrayList<String> al=null;
         String fName = "C:\\Users\\kaps\\Downloads\\CSVFile2.csv";
         String thisLine="";
         String delimiter = ",";
       //  int count=0;
         
        // CSVParser parser = new CSVParserBuilder().withSeparator(',').build(); 
      //   CSVReader csvReader = new CSVReaderBuilder(new FileReader("C:\\Users\\kaps\\Downloads\\CSVFile2.csv")).withSkipLines(1) .withCSVParser(parser) 
          //       .build(); 
         BufferedReader myInput = new BufferedReader(new FileReader(fName));
         int i=0;
         arList = new ArrayList<String>();
         while ((thisLine = myInput.readLine()) != null)
         {
             al = new ArrayList<String>();
             String strar[] = thisLine.split(delimiter);
             for(int j=0;j<strar.length;j++)
             {
            	 HSSFWorkbook hwb = new HSSFWorkbook();
                 HSSFSheet sheet = hwb.createSheet("new sheet");
                 ArrayList<String> ardata = new ArrayList<String>();
                 //for(int k=0;k<arList.size();k++)
                // {
                    
                	//   ardata.add(arList.get(k));
                     HSSFRow row = sheet.createRow(i);
                     //for(int p=0;p<ardata.size();p++)
                     {
                         HSSFCell cell = row.createCell(j);
                        String data = ardata.get(j).toString();
                         if(data.startsWith("=")){
                             cell.setCellType(Cell.CELL_TYPE_STRING);
                             data=data.replaceAll("\"", "");
                             data=data.replaceAll("=", "");
                             cell.setCellValue(data);
                         }else if(data.startsWith("\"")){
                             data=data.replaceAll("\"", "");
                             cell.setCellType(Cell.CELL_TYPE_STRING);
                             cell.setCellValue(data);
                         }else{
                             data=data.replaceAll("\"", "");
                             cell.setCellType(Cell.CELL_TYPE_NUMERIC);
                             cell.setCellValue(data);
                         }
             i++;
         }

         try
         {
           //  HSSFWorkbook hwb = new HSSFWorkbook();
          //   HSSFSheet sheet = hwb.createSheet("new sheet");
            // ArrayList<String> ardata = new ArrayList<String>();
             for(int k=0;k<arList.size();k++)
             {
                
            	   ardata.add(arList.get(k));
             //    HSSFRow row = sheet.createRow((short) 0+k);
                 for(int p=0;p<ardata.size();p++)
                 {
                     HSSFCell cell = row.createCell(p);
                     String data = ardata.get(p).toString();
                     if(data.startsWith("=")){
                         cell.setCellType(Cell.CELL_TYPE_STRING);
                         data=data.replaceAll("\"", "");
                         data=data.replaceAll("=", "");
                         cell.setCellValue(data);
                     }else if(data.startsWith("\"")){
                         data=data.replaceAll("\"", "");
                         cell.setCellType(Cell.CELL_TYPE_STRING);
                         cell.setCellValue(data);
                     }else{
                         data=data.replaceAll("\"", "");
                         cell.setCellType(Cell.CELL_TYPE_NUMERIC);
                         cell.setCellValue(data);
                     }
 //*/
                //   cell.setCellValue(ardata.get(p).toString());
                 }
                 System.out.println();
             }
             FileOutputStream fileOut = new FileOutputStream("C:\\Users\\kaps\\Downloads\\test.xls");
             hwb.write(fileOut);
             fileOut.close();
             myInput.close();
             System.out.println("Your excel file has been generated");
         } catch ( Exception ex ) {
             ex.printStackTrace();
         } //main method ends
     }
 }}}