import java.io.BufferedReader;
import java.io.FileNotFoundException; 
import java.io.FileReader;
import java.io.IOException; 
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
 
public class ParseFullCSVExamples {
   @SuppressWarnings("resource")
   public static void main(String[] args) throws Exception
   {
	   
	   ArrayList<String> arList=null;
      //Build reader instance
	   
	   // create csvParser object with 
       // custom seperator semi-colon 
       CSVParser parser = new CSVParserBuilder().withSeparator(',').build(); 
 
       // create csvReader object with parameter 
       // filereader and parser 
       CSVReader csvReader = new CSVReaderBuilder(new FileReader("C:\\Users\\kaps\\Downloads\\CSVFile2.csv")).withSkipLines(0) .withCSVParser(parser) 
                                 .build(); 
    //  CSVReader reader = new CSVReader(new FileReader("C:\\Users\\kaps\\Downloads\\CSVFile2.csv"), ',', 0);
   //    CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader("Student Name", "Fees"));
      //Read all rows at once
       ArrayList<String[]> allRows = (ArrayList<String[]>) csvReader.readAll();
       //Read CSV line by line and use the string array as you want
      // System.out.println(allRows.size());
       ArrayList<String> AL = new ArrayList<String>();
       
       for(String[] row : allRows){
      	// System.out.println(Arrays.toString(row));
      	 for(String cell:row){
      		AL.add(cell);
      	//	 System.out.println((cell + "\t"));	 
      	 }
       }  
    //  String[] allRows =  csvReader.readAll();
     // DataParser dbparsar = new DataParser(AL, ","); 
      
      HashMap<String,String> PrintValue = new HashMap<String,String>(); 
     // PrintValue = dbparsar.parseData();
      //Iterator<Integer> IT = new PrintValue.iterator();
      
      System.out.println(PrintValue);
      
   }
}