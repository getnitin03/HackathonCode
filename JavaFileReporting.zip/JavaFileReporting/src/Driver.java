import java.io.IOException;
import java.util.HashMap;

public class Driver {

	public static void main(String[] args) {
		try {
			Configuration CF = new Configuration();
			HashMap<String,String> HM = new HashMap<String,String>();
			HM = CF.ReadConfiguration();
			
			String RunPDF = HM.get("PDF_Run");
			String RunExcel = HM.get("Excel_Run");
			String RunCSV = HM.get("CSV_Run");
			String RunXML = HM.get("XML_PDF");
			String RunTXT = HM.get("TXT_Run");
			if(RunPDF.equalsIgnoreCase("YES")){
				ReadPDF RPF = new ReadPDF();
			}else if(RunXML.equalsIgnoreCase("YES")){
				//ReadXML XML = new ReadXML();
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
