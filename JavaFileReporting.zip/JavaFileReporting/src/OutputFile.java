import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet; 
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class OutputFile {
	
	HashMap<String,String> HM = new HashMap<String,String>();
	OutputFile(HashMap HM){
		this.HM = HM;
	}
	public void CreateResultFile() throws FileNotFoundException, IOException{  
		// Blank workbook 
        @SuppressWarnings("resource")
		XSSFWorkbook wb = new XSSFWorkbook();
        XSSFSheet wbsheet = wb.createSheet("Consolidated_Data");
        GregorianCalendar gcalendar = new GregorianCalendar();

	    // Creating Sheets using sheet object 
        // Create a Row
        Row headerRow = wbsheet.createRow(0);
        
        // Create cells
        int i = 0;
        String[] vArray = new String[HM.size()];
        
        for(Map.Entry<String, String> Mobj : HM.entrySet()){
        	
        	//Feed Keys to Column header value
        	Cell cell = headerRow.createCell(i);
        	cell.setCellValue(Mobj.getKey());
        	
        	//Store Value for Rows in array
        	vArray[i] = Mobj.getValue();	
        	i = i+1;
        }
        //Traverse Column
        ArrayList<String> AL = new ArrayList<String>();
        String NewValue = "";
        String OldValue = "";
        for(int j=0;j<vArray.length;j++){
        	String[] spArray = vArray[j].split(",",0);        	
        	//Traverse Rows
        	for(int k=1;k<=spArray.length;k++){
        		if(j==0){
        			AL.add(spArray[k-1].toString());
        		}else{
        			OldValue = AL.get(k-1);
        			AL.remove(k-1);
        			NewValue = OldValue + "," +  spArray[k-1].toString();
        			AL.add(k-1, NewValue);
        		}

        	}
        	int cellCont = 0;
        	for(int l=0;l<AL.size();l++){
        		Row row = wbsheet.createRow(l+1);
        		String[] spAL = AL.get(l).split(",",0);
        		cellCont = 0;
        		for(String el: spAL){
        			row.createCell(cellCont).setCellValue(el);
        			cellCont++;
        		}
        	}
        }
        
        
		// Resize all columns to fit the content size
        for(int m = 0; m < vArray.length; m++) {
            wbsheet.autoSizeColumn(m);
        }
        
        // An output stream accepts output bytes and sends them to sink.
        String TimeStr = gcalendar.get(Calendar.DATE) + "_" + gcalendar.get(Calendar.HOUR) + "_" +gcalendar.get(Calendar.MINUTE) + "_" +gcalendar.get(Calendar.SECOND);
        FileOutputStream fileOut = new FileOutputStream("Result_" + TimeStr + ".xlsx");
        wb.write(fileOut); 
        //fileOut.close();
	}
	 

	
	
}
