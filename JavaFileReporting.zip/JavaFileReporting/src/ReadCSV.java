import java.io.File;
import java.io.IOException;
import java.util.HashMap;
public class ReadCSV {
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {

		Configuration cf = new Configuration();
		
		HashMap<String,String> HM = new HashMap<String,String>();
		HM = cf.ReadConfiguration();
		
		//String CFilePath = "C:\\Users\\kaps\\Downloads\\CSVFile2.csv";
	
		String CFilePath = HM.get("CSV_FilePath");
		
		String CSelectedCol =  HM.get("CSV_SelectedCol").trim();
          String CDelimiter = HM.get("CSV_Delimiter");
		
		
		
		Integer CskipLine = Integer.parseInt((HM.get("CSV_SkipLine")));
		
		String Cquotechar = HM.get("CSV_QuoteChar");
		//System.out.println(Cquotechar);
		
	ParseFullCSV ps = new ParseFullCSV(CFilePath,CSelectedCol,CDelimiter,CskipLine,Cquotechar);
	//	ParseFullTxt ptxt = new ParseFullTxt(CFilePath,CSelectedCol,CDelimiter,CskipLine,Cquotechar);
		ps.methodReadCSV();
		
	//	ptxt.methodReadCSV();
		
		
		
		

 }
}