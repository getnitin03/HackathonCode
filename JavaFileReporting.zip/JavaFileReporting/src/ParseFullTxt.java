import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

public class ParseFullTxt {
	 private String CsvDelmiter ;
	   private String CsvSelectedCol; 
	   private String CsvFilePath;
	   private Integer CsvSkipLine;
	   private String quoteChar;
	    
	   
	  
	   public ParseFullTxt(String CsvFilePath,String CsvSelectedCol,String CsvDelmiter,Integer CsvSkipLine,String quoteChar) {
		// TODO Auto-generated constructor stub
		   
		      this.CsvDelmiter = CsvDelmiter;
		      this.CsvSelectedCol = CsvSelectedCol;
		      this.CsvFilePath = CsvFilePath;
		      this.CsvSkipLine = CsvSkipLine;
		      this.quoteChar = quoteChar;
	}


		//public static void main(String[] args) throws IOException {

		  
	 @SuppressWarnings("unchecked")
	public void methodReadCSV() throws IOException { 
		  // ArrayList<String> arList=null;
		 
		   char csvDelim = (this.CsvDelmiter).replace("\"","").charAt(0);
		   char csvQuote = (this.quoteChar).charAt(0);
		 // System.out.println(csvDelim);
	      
		  BufferedReader br = new BufferedReader(new FileReader(this.CsvFilePath));
	           
	       String HeaderSelect;
	       
	       if(!(this.CsvSelectedCol).equals(null)){
	    	     HeaderSelect = this.CsvSelectedCol;
	    	 
	    			  
	    		  
	       }else{
	    	   HeaderSelect = null;
	       }
	       
	    	if(!(br.equals(null))){
	    		String line = null;
	 	       String[] tempArr;
	 	      ArrayList<String> AL = new ArrayList<String>();
	 	       while ((line = br.readLine())!=null){
	 	    	  tempArr = line.split((this.CsvDelmiter).replace("\"",""));
	 	    	 // for(int e=0;e<tempArr.length;e++){
	 	    		 AL.add(line);
	 	    	  //}
	 	       }
	    	              
	     
	     DataParser dbparsar = new DataParser(AL, ",",HeaderSelect); 
	      
	      HashMap<String,String> PrintValue = new HashMap<String,String>(); 
	          PrintValue = dbparsar.parseData();
	      	      
	      System.out.println(PrintValue);
	      OutputFile OF = new OutputFile(PrintValue);
		     OF.CreateResultFile();
			
	    	}
	   }
	}
