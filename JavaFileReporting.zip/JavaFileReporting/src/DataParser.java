import java.util.ArrayList;
import java.util.HashMap;

public class DataParser {

	ArrayList<String> al1 = new ArrayList<String>();
    String delim;
    String selCol ;
	
	public DataParser(ArrayList al1,String delim,String headerSelect){

		this.al1 = al1;
		this.delim = delim;
		this.selCol = headerSelect;
		
	}
	
	@SuppressWarnings("rawtypes")
	public HashMap parseData(){
		
		HashMap<String,String> hmObj = new HashMap<String,String>();
		
		String kvalue = null;
		String Dvalue = null;
		String[] skvalue = null;
		String [] SDValue = null;
		String [] HeadSelCol = null;
		System.out.println(al1.size());
		for(int i = 0;i<al1.size();i++){
          
			if (i == 0){
	        	//System.out.println(al1);
			kvalue = al1.get(i);
			//System.out.println(kvalue);
			 skvalue = kvalue.split(delim,0);
			 HeadSelCol =selCol.trim().split(delim,0);
			 //System.out.println(HeadSelCol);
			}
			else if(i == 1){
				
				Dvalue =al1.get(i);
				 SDValue = Dvalue.split(delim,0);
				 
				 if(!this.selCol.equalsIgnoreCase("All")){
					
		            	for(int m=0;m<HeadSelCol.length;m++){
		            		//System.out.println("inside");
		            		for(int j =0;j<SDValue.length;j++){
		            			if(HeadSelCol[m].equalsIgnoreCase(skvalue[j]) ){
		            				//System.out.println("insidelop");
		            				hmObj.put(skvalue[j], SDValue[j]);
		            			     }
		            		   }  
		    					            		
		            	    }
				 }else{    	
				for(int j =0;j<SDValue.length;j++){
					hmObj.put(skvalue[j], SDValue[j]);
					
				}}
				//System.out.println(hmObj);
			}
			else {
				
				String restDvalue = al1.get(i);
				String [] SDRValue = restDvalue.split(delim,0);
				
				 if(!this.selCol.equalsIgnoreCase("All")){
		            	for(int m=0;m<HeadSelCol.length;m++){
		            		//System.out.println("inside2");
		            		for(int j =0;j<SDRValue.length;j++){
		            			if(HeadSelCol[m].equalsIgnoreCase(skvalue[j]) ){
		            				String ExistValue = hmObj.get(skvalue[j]);
		            				String NewValue = ExistValue +"," + SDRValue[j];
		    						hmObj.put(skvalue[j], NewValue);
		    						 }
		            		   }  
		    					            		
		            	    }
				 }else{    	
					
				
					for(int j =0;j<SDRValue.length;j++){
						String ExistValue = hmObj.get(skvalue[j]);
						//System.out.println(ExistValue);
						String NewValue = ExistValue +"," + SDRValue[j];
						hmObj.put(skvalue[j], NewValue);
						
					}}
			}
			
		
		}
		return hmObj;
	}		


}
