

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
public class ReadPDF {
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException{
		
		//Read Configuration file
		Configuration CF = new Configuration();
		HashMap<String,String> HM = new HashMap<String,String>();
		HM = CF.ReadConfiguration();
		
		//Assign values
		//System.out.println(HM.get("PDF_FilePath"));
		String PFilepath = HM.get("PDF_FilePath").replace("\\", "/");
		//String PFilepath = "C:/Users/HP/Downloads/SampleInputs/pdf-test.pdf";
		Integer SPage = Integer.parseInt(HM.get("PDF_StartPage")); //starting Page
		Integer LPage = Integer.parseInt(HM.get("PDF_LastPage")); //last page
		Integer SpPage = Integer.parseInt(HM.get("PDF_SpecificPage")); //specific page
		String readAll = HM.get("PDF_ReadAll");
		Integer SRow = Integer.parseInt(HM.get("PDF_StartLine"));; //Start row
		Integer LRow = 0; // last row
		
		
		//Call PDF Class
		PDF_Class PD = new PDF_Class(PFilepath,SPage,LPage,SpPage,SRow,LRow,readAll,SRow);
		//String PDF_Text = PD.ReadPDFFile();
		PD.ReadPDFFile();
		//System.out.println(PDF_Text);
	}

}
